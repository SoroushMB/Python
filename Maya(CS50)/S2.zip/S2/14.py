Avengers = {
    "Iron Man" : "Tech",
    "War Machine" : "Tech",
    "Hulk" : "Super bi asab!!!!"
}
for avenger in Avengers:
    print(avenger, Avengers[avenger], sep=":")