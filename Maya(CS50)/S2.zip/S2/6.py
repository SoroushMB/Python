sound = "meow"
count = 10
print(f"{sound}\n"*count)