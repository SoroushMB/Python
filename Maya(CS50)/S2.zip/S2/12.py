planets = ["Mercury","Venus","Neptune"]
for i in range(len(planets)):
    print(f"{i+1}:{planets[i]}")