counter = 1 # 2 - 3 -...- 9 - 10
while counter <= 10:
    print("meow")
    counter += 1
    # break