# Slicing
planets = ["Mercury","Venus","Neptune"]
print(planets[0])
print(planets[1])
print(planets[2])
print(planets[3])
