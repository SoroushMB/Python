for _ in range(10):
    print("meow")