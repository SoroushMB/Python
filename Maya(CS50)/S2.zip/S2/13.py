Avengers = {
    # key = value -> item
    "Iron Man" : "Tech",
    "War Machine" : "Tech",
    "Hulk" : "Super bi asab!!!!"
}
print(Avengers["War Machine"])
print(Avengers["Hulk"])
print(Avengers["Iron Man"])