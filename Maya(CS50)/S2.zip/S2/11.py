# Iterating
planets = ["Mercury","Venus","Neptune"]
for planet in planets:
    print(planet)