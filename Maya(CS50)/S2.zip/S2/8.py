while True:
    number = int(input(">> "))
    if number > 0:
        break
print("Finished!")