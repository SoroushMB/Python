counter = 10 # 9 - 8 -...- 1 - 0
while counter != 0:
    print("meow")
    counter -= 1
    # break